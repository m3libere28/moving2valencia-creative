Open 15-new-horizon/index.html. The standalone A-New-Horizon.html is also available in the review collection. Original supplied archives are unchanged.
